// Enhanced AI Engine for ScheduleAI
// Advanced machine learning capabilities for educational scheduling

class EnhancedAIEngine {
    constructor() {
        this.userProfile = {
            learningStyle: 'mixed',
            focusTime: 25,
            breakInterval: 10,
            peakHours: [10, 11, 14, 15],
            difficultSubjects: ['Advanced Algorithms'],
            preferredStudyMethods: ['pomodoro', 'active_recall'],
            productivityPatterns: {
                morning: 0.85,
                afternoon: 0.75,
                evening: 0.65
            },
            historicalPerformance: {
                'Advanced Algorithms': { grade: 88, effort: 4.2, timeSpent: 45 },
                'Database Systems': { grade: 92, effort: 3.1, timeSpent: 32 },
                'Software Engineering': { grade: 85, effort: 3.8, timeSpent: 38 }
            }
        };
        
        this.conversationHistory = [];
        this.intentPatterns = {
            schedule: /schedule|plan|organize|calendar/i,
            assignment: /assignment|homework|due|deadline/i,
            study: /study|learn|review|prepare/i,
            break: /break|rest|pause|relax/i,
            difficulty: /difficult|hard|struggle|confused/i,
            motivation: /motivation|inspiration|focus|concentrate/i
        };
        
        this.studyStrategies = {
            visual: [
                'Create mind maps and diagrams',
                'Use color-coded notes and highlights',
                'Watch educational videos and animations',
                'Draw concept maps and flowcharts',
                'Use flashcards with images'
            ],
            auditory: [
                'Record lectures and listen to playback',
                'Explain concepts out loud to yourself',
                'Participate in group discussions',
                'Use mnemonic devices and rhymes',
                'Listen to educational podcasts'
            ],
            kinesthetic: [
                'Take hands-on practice approaches',
                'Use physical movement while studying',
                'Build models or physical representations',
                'Take frequent breaks for movement',
                'Use manipulatives and interactive tools'
            ]
        };
        
        this.init();
    }

    init() {
        this.loadUserProfile();
        this.initializeChatbot();
        this.startPatternAnalysis();
    }

    loadUserProfile() {
        // Load user profile from localStorage or create default
        const savedProfile = localStorage.getItem('aiUserProfile');
        if (savedProfile) {
            this.userProfile = { ...this.userProfile, ...JSON.parse(savedProfile) };
        }
    }

    saveUserProfile() {
        localStorage.setItem('aiUserProfile', JSON.stringify(this.userProfile));
    }

    // Advanced NLP for intent recognition
    analyzeIntent(message) {
        const intents = [];
        const lowerMessage = message.toLowerCase();
        
        Object.keys(this.intentPatterns).forEach(intent => {
            if (this.intentPatterns[intent].test(lowerMessage)) {
                intents.push(intent);
            }
        });
        
        // Determine primary intent
        const primaryIntent = this.determinePrimaryIntent(intents, lowerMessage);
        
        return {
            primary: primaryIntent,
            secondary: intents.filter(i => i !== primaryIntent),
            confidence: this.calculateConfidence(intents, lowerMessage)
        };
    }

    determinePrimaryIntent(intents, message) {
        if (intents.length === 0) return 'general';
        if (intents.length === 1) return intents[0];
        
        // Priority-based intent selection
        const priorities = {
            schedule: 5,
            assignment: 4,
            study: 3,
            difficulty: 2,
            motivation: 1,
            break: 0
        };
        
        return intents.reduce((primary, current) => 
            priorities[current] > priorities[primary] ? current : primary
        );
    }

    calculateConfidence(intents, message) {
        if (intents.length === 0) return 0.3;
        if (intents.length === 1) return 0.8;
        if (intents.length >= 2) return 0.9;
        return 0.6;
    }

    // Generate contextual responses
    generateResponse(message, context = {}) {
        const intent = this.analyzeIntent(message);
        this.conversationHistory.push({ message, intent, timestamp: new Date() });
        
        // Keep only last 10 conversations for context
        if (this.conversationHistory.length > 10) {
            this.conversationHistory = this.conversationHistory.slice(-10);
        }
        
        let response;
        
        switch (intent.primary) {
            case 'schedule':
                response = this.handleScheduleQuery(message, context);
                break;
            case 'assignment':
                response = this.handleAssignmentQuery(message, context);
                break;
            case 'study':
                response = this.handleStudyQuery(message, context);
                break;
            case 'difficulty':
                response = this.handleDifficultyQuery(message, context);
                break;
            case 'motivation':
                response = this.handleMotivationQuery(message, context);
                break;
            case 'break':
                response = this.handleBreakQuery(message, context);
                break;
            default:
                response = this.handleGeneralQuery(message, context);
        }
        
        return {
            ...response,
            intent: intent.primary,
            confidence: intent.confidence
        };
    }

    handleScheduleQuery(message, context) {
        const responses = [
            "I can help you optimize your schedule! Based on your performance patterns, I recommend studying difficult subjects during your peak hours (10-11 AM).",
            "Looking at your current schedule, you have some free time on Tuesday afternoons. Would you like me to suggest study blocks for that time?",
            "Your schedule looks good, but I notice you have back-to-back difficult classes on Wednesday. Consider adding a 30-minute break between them.",
            "I've analyzed your productivity patterns and suggest moving your Database Systems study session to Thursday morning when you're most focused."
        ];
        
        return {
            text: responses[Math.floor(Math.random() * responses.length)],
            suggestions: [
                "Move Algorithms study to 10:00 AM",
                "Add break between CS classes",
                "Schedule review session for Friday"
            ],
            actions: ['optimizeSchedule', 'addBreak', 'reschedule'],
            type: 'schedule'
        };
    }

    handleAssignmentQuery(message, context) {
        const urgentAssignments = this.getUrgentAssignments();
        const difficultyAnalysis = this.analyzeAssignmentDifficulty();
        
        return {
            text: `You have ${urgentAssignments.length} assignments due soon. Based on difficulty analysis, I recommend starting with your Database Design Project as it requires the most preparation time.`,
            suggestions: urgentAssignments.map(a => `${a.title} - Due: ${a.dueDate}`),
            priorityOrder: this.calculateAssignmentPriority(),
            estimatedTime: this.estimateAssignmentTime(),
            type: 'assignment'
        };
    }

    handleStudyQuery(message, context) {
        const learningStyle = this.userProfile.learningStyle;
        const strategies = this.studyStrategies[learningStyle] || this.studyStrategies.mixed;
        const recommendedStrategy = strategies[Math.floor(Math.random() * strategies.length)];
        
        return {
            text: `Based on your ${learningStyle} learning style, I recommend: ${recommendedStrategy}. Would you like me to create a study session with this approach?`,
            strategies: strategies,
            recommendedMethod: recommendedStrategy,
            studyPlan: this.generateStudyPlan(),
            type: 'study'
        };
    }

    handleDifficultyQuery(message, context) {
        const difficultSubjects = this.userProfile.difficultSubjects;
        const studyMethods = [
            "Break down complex topics into smaller chunks",
            "Use the Feynman technique - explain concepts in simple terms",
            "Create visual diagrams and mind maps",
            "Practice with past exam questions",
            "Form a study group for collaborative learning"
        ];
        
        return {
            text: `I understand you're finding ${difficultSubjects.join(', ')} challenging. This is normal! Let me suggest some targeted strategies to help you master these subjects.`,
            strategies: studyMethods,
            resources: this.getSubjectResources(difficultSubjects),
            tutoringSuggestions: this.findTutoringOptions(),
            type: 'difficulty'
        };
    }

    handleMotivationQuery(message, context) {
        const motivationalQuotes = [
            "The expert in anything was once a beginner.",
            "Success is the sum of small efforts repeated day in and day out.",
            "Don't wish it were easier, wish you were better.",
            "The way to get started is to quit talking and begin doing.",
            "Your future is created by what you do today, not tomorrow."
        ];
        
        const progress = this.calculateUserProgress();
        
        return {
            text: motivationalQuotes[Math.floor(Math.random() * motivationalQuotes.length)],
            progress: progress,
            achievements: this.getRecentAchievements(),
            nextMilestone: this.getNextMilestone(),
            type: 'motivation'
        };
    }

    handleBreakQuery(message, context) {
        const breakActivities = [
            "Take a 10-minute walk outside",
            "Do some light stretching",
            "Practice deep breathing exercises",
            "Listen to your favorite song",
            "Grab a healthy snack",
            "Do a quick meditation session"
        ];
        
        return {
            text: "Great idea! Taking breaks improves retention and focus. Here's what I suggest:",
            activities: breakActivities,
            optimalBreakLength: this.userProfile.breakInterval,
            breakTimer: this.createBreakTimer(),
            type: 'break'
        };
    }

    handleGeneralQuery(message, context) {
        const generalResponses = [
            "I'm here to help with your academic scheduling! You can ask me about optimizing your study time, managing assignments, or getting study tips.",
            "I can help you create study plans, track your progress, and suggest improvements to your schedule. What would you like to work on?",
            "Feel free to ask me anything about studying, assignments, or schedule optimization. I'm designed to help you succeed academically!"
        ];
        
        return {
            text: generalResponses[Math.floor(Math.random() * generalResponses.length)],
            capabilities: this.getAICapabilities(),
            quickActions: this.getQuickActions(),
            type: 'general'
        };
    }

    // Predictive analytics for study optimization
    predictOptimalStudyTime(course, duration) {
        const courseDifficulty = this.getCourseDifficulty(course);
        const userProductivity = this.userProfile.productivityPatterns;
        
        // Machine learning-inspired prediction
        const predictions = {};
        
        Object.keys(userProductivity).forEach(timeOfDay => {
            const baseProductivity = userProductivity[timeOfDay];
            const difficultyMultiplier = courseDifficulty / 10;
            const optimalScore = baseProductivity * (1 - difficultyMultiplier * 0.1);
            
            predictions[timeOfDay] = {
                score: optimalScore,
                estimatedCompletion: duration / optimalScore,
                confidence: this.calculatePredictionConfidence(course, timeOfDay)
            };
        });
        
        return predictions;
    }

    calculatePredictionConfidence(course, timeOfDay) {
        const historicalData = this.userProfile.historicalPerformance[course];
        if (!historicalData) return 0.7;
        
        const consistency = historicalData.grade / 100;
        const effortRatio = historicalData.effort / 5;
        
        return Math.min(0.95, (consistency + effortRatio) / 2);
    }

    // Intelligent assignment prioritization
    prioritizeAssignments(assignments) {
        return assignments.map(assignment => {
            const difficulty = this.getCourseDifficulty(assignment.course);
            const urgency = this.calculateUrgency(assignment.dueDate);
            const importance = this.calculateImportance(assignment.course);
            
            const priorityScore = (difficulty * 0.3 + urgency * 0.4 + importance * 0.3);
            
            return {
                ...assignment,
                priorityScore,
                estimatedTime: this.estimateAssignmentTime(assignment),
                recommendedStartDate: this.calculateRecommendedStartDate(assignment, difficulty)
            };
        }).sort((a, b) => b.priorityScore - a.priorityScore);
    }

    // Adaptive learning path generation
    generateLearningPath(subject, currentLevel, targetLevel) {
        const topics = this.getSubjectTopics(subject);
        const learningPath = [];
        
        topics.forEach(topic => {
            const difficulty = this.calculateTopicDifficulty(topic);
            const prerequisite = this.getPrerequisites(topic);
            
            if (this.canUnderstandTopic(currentLevel, difficulty, prerequisite)) {
                learningPath.push({
                    topic,
                    difficulty,
                    estimatedTime: this.estimateTopicTime(topic, difficulty),
                    resources: this.getTopicResources(topic),
                    practiceExercises: this.getPracticeExercises(topic),
                    masteryLevel: this.calculateMasteryRequirement(topic, targetLevel)
                });
            }
        });
        
        return this.optimizeLearningOrder(learningPath);
    }

    // Real-time performance monitoring and feedback
    analyzeStudySession(sessionData) {
        const analysis = {
            focusScore: this.calculateFocusScore(sessionData),
            efficiency: this.calculateEfficiency(sessionData),
            fatigueLevel: this.detectFatigue(sessionData),
            comprehension: this.assessComprehension(sessionData),
            recommendations: []
        };
        
        if (analysis.focusScore < 0.7) {
            analysis.recommendations.push("Consider taking a short break to improve focus");
        }
        
        if (analysis.fatigueLevel > 0.8) {
            analysis.recommendations.push("You seem tired. Consider ending this session");
        }
        
        if (analysis.comprehension < 0.6) {
            analysis.recommendations.push("Try reviewing the material with a different approach");
        }
        
        return analysis;
    }

    // Chatbot interface
    initializeChatbot() {
        this.createChatbotUI();
        this.bindChatbotEvents();
    }

    createChatbotUI() {
        const chatbotHTML = `
            <div id="ai-chatbot" class="chatbot-container">
                <div class="chatbot-header">
                    <div class="chatbot-avatar">🤖</div>
                    <div class="chatbot-title">AI Study Assistant</div>
                    <button class="chatbot-toggle" id="chatbot-toggle">💬</button>
                </div>
                <div class="chatbot-messages" id="chatbot-messages"></div>
                <div class="chatbot-input-container">
                    <input type="text" id="chatbot-input" placeholder="Ask me anything about your studies..." />
                    <button id="chatbot-send">Send</button>
                </div>
            </div>
        `;
        
        document.body.insertAdjacentHTML('beforeend', chatbotHTML);
        this.addChatbotStyles();
    }

    addChatbotStyles() {
        const styles = `
            <style>
                .chatbot-container {
                    position: fixed;
                    bottom: 20px;
                    right: 20px;
                    width: 350px;
                    height: 500px;
                    background: white;
                    border-radius: 12px;
                    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
                    display: flex;
                    flex-direction: column;
                    z-index: 1000;
                    transition: all 0.3s ease;
                }
                
                .chatbot-container.minimized {
                    height: 60px;
                }
                
                .chatbot-header {
                    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                    color: white;
                    padding: 12px 16px;
                    border-radius: 12px 12px 0 0;
                    display: flex;
                    align-items: center;
                    gap: 12px;
                }
                
                .chatbot-avatar {
                    font-size: 1.5rem;
                }
                
                .chatbot-title {
                    flex: 1;
                    font-weight: 600;
                }
                
                .chatbot-toggle {
                    background: none;
                    border: none;
                    color: white;
                    font-size: 1.2rem;
                    cursor: pointer;
                }
                
                .chatbot-messages {
                    flex: 1;
                    padding: 16px;
                    overflow-y: auto;
                    display: flex;
                    flex-direction: column;
                    gap: 12px;
                }
                
                .chatbot-message {
                    max-width: 80%;
                    padding: 12px 16px;
                    border-radius: 18px;
                    font-size: 0.9rem;
                    line-height: 1.4;
                }
                
                .chatbot-message.user {
                    background: #4A90E2;
                    color: white;
                    align-self: flex-end;
                    border-bottom-right-radius: 6px;
                }
                
                .chatbot-message.ai {
                    background: #f0f0f0;
                    color: #333;
                    align-self: flex-start;
                    border-bottom-left-radius: 6px;
                }
                
                .chatbot-input-container {
                    padding: 12px 16px;
                    border-top: 1px solid #e0e0e0;
                    display: flex;
                    gap: 8px;
                }
                
                .chatbot-input-container input {
                    flex: 1;
                    padding: 8px 12px;
                    border: 1px solid #ddd;
                    border-radius: 20px;
                    font-size: 0.9rem;
                }
                
                .chatbot-input-container button {
                    padding: 8px 16px;
                    background: #4A90E2;
                    color: white;
                    border: none;
                    border-radius: 20px;
                    cursor: pointer;
                    font-size: 0.9rem;
                }
                
                .chatbot-suggestion {
                    background: rgba(74, 144, 226, 0.1);
                    border: 1px solid rgba(74, 144, 226, 0.3);
                    border-radius: 8px;
                    padding: 8px 12px;
                    margin: 4px 0;
                    cursor: pointer;
                    font-size: 0.8rem;
                    transition: all 0.2s ease;
                }
                
                .chatbot-suggestion:hover {
                    background: rgba(74, 144, 226, 0.2);
                }
            </style>
        `;
        
        document.head.insertAdjacentHTML('beforeend', styles);
    }

    bindChatbotEvents() {
        const toggle = document.getElementById('chatbot-toggle');
        const input = document.getElementById('chatbot-input');
        const sendBtn = document.getElementById('chatbot-send');
        const container = document.getElementById('ai-chatbot');
        
        toggle.addEventListener('click', () => {
            container.classList.toggle('minimized');
        });
        
        const sendMessage = () => {
            const message = input.value.trim();
            if (message) {
                this.addChatMessage(message, 'user');
                this.processChatMessage(message);
                input.value = '';
            }
        };
        
        sendBtn.addEventListener('click', sendMessage);
        input.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') sendMessage();
        });
        
        // Add welcome message
        setTimeout(() => {
            this.addChatMessage("Hi! I'm your AI study assistant. I can help you with scheduling, assignments, study strategies, and more. What would you like to know?", 'ai');
        }, 1000);
    }

    addChatMessage(message, sender) {
        const messagesContainer = document.getElementById('chatbot-messages');
        const messageElement = document.createElement('div');
        messageElement.className = `chatbot-message ${sender}`;
        messageElement.textContent = message;
        
        messagesContainer.appendChild(messageElement);
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }

    processChatMessage(message) {
        setTimeout(() => {
            const response = this.generateResponse(message);
            this.addChatMessage(response.text, 'ai');
            
            // Add suggestions if available
            if (response.suggestions && response.suggestions.length > 0) {
                response.suggestions.forEach((suggestion, index) => {
                    const suggestionElement = document.createElement('div');
                    suggestionElement.className = 'chatbot-suggestion';
                    suggestionElement.textContent = suggestion;
                    suggestionElement.addEventListener('click', () => {
                        document.getElementById('chatbot-input').value = suggestion;
                    });
                    
                    document.getElementById('chatbot-messages').appendChild(suggestionElement);
                });
            }
        }, 1000);
    }

    // Pattern analysis for continuous improvement
    startPatternAnalysis() {
        setInterval(() => {
            this.analyzeUserPatterns();
            this.updateRecommendations();
        }, 300000); // Analyze every 5 minutes
    }

    analyzeUserPatterns() {
        // Analyze study patterns, productivity, and preferences
        const recentSessions = this.getRecentStudySessions();
        const patternAnalysis = this.detectPatterns(recentSessions);
        
        // Update user profile based on patterns
        if (patternAnalysis.newPeakHours) {
            this.userProfile.peakHours = patternAnalysis.newPeakHours;
        }
        
        if (patternAnalysis.preferredMethods) {
            this.userProfile.preferredStudyMethods = patternAnalysis.preferredMethods;
        }
        
        this.saveUserProfile();
    }

    // Utility methods
    getUrgentAssignments() {
        return [
            { title: 'Dynamic Programming Assignment', course: 'Advanced Algorithms', dueDate: '2025-10-30', priority: 'high' },
            { title: 'Database Design Project', course: 'Database Systems', dueDate: '2025-11-05', priority: 'high' }
        ];
    }

    calculateAssignmentPriority() {
        return [
            { assignment: 'Dynamic Programming Assignment', priority: 9.2, reason: 'Due soon + high difficulty' },
            { assignment: 'Database Design Project', priority: 8.5, reason: 'Significant time requirement' }
        ];
    }

    estimateAssignmentTime(assignment = null) {
        return assignment ? `${Math.floor(Math.random() * 4) + 2} hours` : '3-5 hours';
    }

    calculateUserProgress() {
        return {
            weeklyGoal: 85,
            currentProgress: 78,
            streak: 7,
            improvement: '+12% from last month'
        };
    }

    getRecentAchievements() {
        return [
            '7-day study streak!',
            'Completed all assignments on time this week',
            'Improved focus score by 15%'
        ];
    }

    getNextMilestone() {
        return {
            title: 'Study Master',
            description: 'Maintain 10-day study streak',
            progress: '70%'
        };
    }

    getAICapabilities() {
        return [
            'Schedule optimization',
            'Assignment prioritization',
            'Study method recommendations',
            'Performance analytics',
            'Difficulty assessment',
            'Motivation and encouragement'
        ];
    }

    getQuickActions() {
        return [
            'Optimize my schedule',
            'Prioritize assignments',
            'Start focus session',
            'Get study tips'
        ];
    }

    getCourseDifficulty(course) {
        const difficulties = {
            'Advanced Algorithms': 9,
            'Database Systems': 6,
            'Software Engineering': 7
        };
        return difficulties[course] || 5;
    }

    generateStudyPlan() {
        return {
            duration: '2 hours',
            method: 'Pomodoro Technique',
            breaks: '10 minutes every 25 minutes',
            focusAreas: ['Dynamic Programming', 'Database Normalization']
        };
    }

    createBreakTimer() {
        return {
            duration: this.userProfile.breakInterval,
            activities: ['Walk', 'Stretch', 'Hydrate', 'Deep breathing']
        };
    }
}

// Initialize enhanced AI engine when DOM is loaded
let aiEngine;

document.addEventListener('DOMContentLoaded', () => {
    aiEngine = new EnhancedAIEngine();
    
    // Make AI engine globally accessible
    window.aiEngine = aiEngine;
    
    console.log('Enhanced AI Engine initialized successfully!');
});