// ApolloAI - Main JavaScript Functionality
// Intelligent Academic Navigation System

// Global state management
const AppState = {
    currentUser: {
        name: 'Alex Johnson',
        major: 'Computer Science',
        year: 'Junior',
        gpa: 3.8,
        studyStreak: 7,
        totalStudyTime: 127.5
    },
    courses: [
        {
            id: 1,
            name: 'Advanced Algorithms',
            code: 'CS 401',
            time: 'Mon, Wed 10:00-11:30',
            color: '#27ae60',
            instructor: 'Dr. Smith',
            credits: 3,
            difficulty: 9,
            grade: 88
        },
        {
            id: 2,
            name: 'Database Systems',
            code: 'CS 350',
            time: 'Tue, Thu 14:00-15:30',
            color: '#0f3460',
            instructor: 'Prof. Johnson',
            credits: 3,
            difficulty: 6,
            grade: 92
        },
        {
            id: 3,
            name: 'Software Engineering',
            code: 'CS 420',
            time: 'Fri 09:00-12:00',
            color: '#f39c12',
            instructor: 'Dr. Williams',
            credits: 4,
            difficulty: 7,
            grade: 85
        }
    ],
    assignments: [
        {
            id: 1,
            courseId: 1,
            title: 'Dynamic Programming Assignment',
            dueDate: '2025-10-30',
            priority: 'high',
            completed: false,
            estimatedTime: 8,
            progress: 75
        },
        {
            id: 2,
            courseId: 2,
            title: 'Database Design Project',
            dueDate: '2025-11-05',
            priority: 'medium',
            completed: false,
            estimatedTime: 15,
            progress: 45
        }
    ],
    studySessions: [
        {
            id: 1,
            date: '2025-10-25',
            duration: 2.5,
            course: 'Advanced Algorithms',
            focusScore: 85,
            method: 'pomodoro'
        }
    ],
    weeklySchedule: {
        'Monday': [{ course: 'Advanced Algorithms', time: '10:00-11:30', type: 'lecture' }],
        'Tuesday': [{ course: 'Database Systems', time: '14:00-15:30', type: 'lecture' }],
        'Wednesday': [{ course: 'Advanced Algorithms', time: '10:00-11:30', type: 'lecture' }],
        'Thursday': [{ course: 'Database Systems', time: '14:00-15:30', type: 'lecture' }],
        'Friday': [{ course: 'Software Engineering', time: '09:00-12:00', type: 'lecture' }]
    },
    goals: [
        {
            id: 1,
            title: 'Complete Algorithm Assignment',
            type: 'assignment',
            progress: 75,
            deadline: '2025-10-30',
            completed: false
        },
        {
            id: 2,
            title: 'Weekly Study Hours Target',
            type: 'study-time',
            progress: 93,
            deadline: '2025-10-27',
            completed: false
        }
    ]
};

// Utility functions
function formatDate(date) {
    return new Date(date).toLocaleDateString('en-US', {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });
}

function getTimeSlot(date, time) {
    const [startTime] = time.split('-');
    const [hours, minutes] = startTime.split(':').map(Number);
    const slotDate = new Date(date);
    slotDate.setHours(hours, minutes, 0, 0);
    return slotDate;
}

function generateId() {
    return Date.now() + Math.random().toString(36).substr(2, 9);
}

// Calendar functionality
class CalendarManager {
    constructor() {
        this.currentWeek = new Date();
        this.selectedDate = null;
        this.init();
    }

    init() {
        this.renderCalendar();
        this.bindEvents();
    }

    renderCalendar() {
        const calendarGrid = document.getElementById('calendar-grid');
        if (!calendarGrid) return;

        const weekDays = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
        const timeSlots = this.generateTimeSlots();

        let html = '<div class="calendar-container">';
        
        // Header with days
        html += '<div class="calendar-header">';
        html += '<div class="time-column-header">Time</div>';
        weekDays.forEach(day => {
            html += `<div class="day-header">${day}</div>`;
        });
        html += '</div>';

        // Time slots and course grid
        timeSlots.forEach(timeSlot => {
            html += '<div class="time-row">';
            html += `<div class="time-slot">${timeSlot}</div>`;
            
            weekDays.forEach(day => {
                const slotId = `${day}-${timeSlot}`;
                html += `<div class="calendar-cell" data-slot="${slotId}" data-day="${day}" data-time="${timeSlot}">
                    <div class="cell-content"></div>
                </div>`;
            });
            html += '</div>';
        });

        html += '</div>';
        calendarGrid.innerHTML = html;

        this.populateCalendar();
    }

    generateTimeSlots() {
        const slots = [];
        for (let hour = 8; hour < 20; hour++) {
            const startTime = `${hour.toString().padStart(2, '0')}:00`;
            const endTime = `${(hour + 1).toString().padStart(2, '0')}:00`;
            slots.push(`${startTime}-${endTime}`);
        }
        return slots;
    }

    populateCalendar() {
        Object.keys(AppState.weeklySchedule).forEach(day => {
            AppState.weeklySchedule[day].forEach(schedule => {
                const timeSlot = schedule.time;
                const slotId = `${day}-${timeSlot}`;
                const cell = document.querySelector(`[data-slot="${slotId}"]`);
                
                if (cell) {
                    const course = AppState.courses.find(c => c.name === schedule.course);
                    if (course) {
                        this.renderCourseInCell(cell, course, schedule);
                    }
                }
            });
        });
    }

    renderCourseInCell(cell, course, schedule) {
        const content = cell.querySelector('.cell-content');
        content.innerHTML = `
            <div class="course-block" style="background-color: ${course.color}20; border-left: 4px solid ${course.color}">
                <div class="course-code">${course.code}</div>
                <div class="course-name">${course.name}</div>
                <div class="course-time">${schedule.time}</div>
            </div>
        `;
        
        cell.classList.add('has-course');
        cell.setAttribute('data-course-id', course.id);
    }

    bindEvents() {
        // Click to add course
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('calendar-cell') && !e.target.classList.contains('has-course')) {
                this.showAddCourseModal(e.target);
            }
        });

        // Drag and drop functionality
        this.initializeDragAndDrop();
    }

    showAddCourseModal(cell) {
        const day = cell.getAttribute('data-day');
        const time = cell.getAttribute('data-time');
        
        const modal = document.getElementById('course-modal');
        const form = document.getElementById('course-form');
        
        if (modal && form) {
            form.reset();
            document.getElementById('course-day').value = day;
            document.getElementById('course-time').value = time;
            
            modal.style.display = 'flex';
            anime({
                targets: modal.querySelector('.modal-content'),
                scale: [0.8, 1],
                opacity: [0, 1],
                duration: 300,
                easing: 'easeOutCubic'
            });
        }
    }

    initializeDragAndDrop() {
        let draggedElement = null;

        document.addEventListener('dragstart', (e) => {
            if (e.target.classList.contains('course-block')) {
                draggedElement = e.target.closest('.calendar-cell');
                e.dataTransfer.effectAllowed = 'move';
            }
        });

        document.addEventListener('dragover', (e) => {
            e.preventDefault();
            e.dataTransfer.dropEffect = 'move';
        });

        document.addEventListener('drop', (e) => {
            e.preventDefault();
            if (draggedElement && e.target.classList.contains('calendar-cell')) {
                this.moveCourse(draggedElement, e.target);
            }
        });
    }

    moveCourse(fromCell, toCell) {
        const courseId = fromCell.getAttribute('data-course-id');
        const course = AppState.courses.find(c => c.id == courseId);
        
        if (course && !toCell.classList.contains('has-course')) {
            // Update schedule data
            const fromDay = fromCell.getAttribute('data-day');
            const toDay = toCell.getAttribute('data-day');
            const toTime = toCell.getAttribute('data-time');
            
            // Remove from old schedule
            AppState.weeklySchedule[fromDay] = AppState.weeklySchedule[fromDay].filter(
                s => s.course !== course.name
            );
            
            // Add to new schedule
            AppState.weeklySchedule[toDay].push({
                course: course.name,
                time: toTime,
                type: 'lecture'
            });
            
            // Re-render calendar
            this.renderCalendar();
            this.showNotification('Course moved successfully!', 'success');
        }
    }
}

// AI Recommendation Engine
class AIRecommendationEngine {
    constructor() {
        this.recommendations = [];
        this.init();
    }

    init() {
        this.generateRecommendations();
        this.renderRecommendations();
    }

    generateRecommendations() {
        const currentTime = new Date().getHours();
        const dayOfWeek = new Date().getDay();
        
        this.recommendations = [
            {
                type: 'study_time',
                title: 'Optimal Study Time',
                description: `Based on your schedule, ${this.getOptimalStudyTime(currentTime)}`,
                icon: '⏰',
                priority: 'high'
            },
            {
                type: 'break_reminder',
                title: 'Take a Break',
                description: this.getBreakRecommendation(currentTime),
                icon: '🧘',
                priority: 'medium'
            },
            {
                type: 'assignment_priority',
                title: 'Priority Assignment',
                description: this.getPriorityAssignment(),
                icon: '📝',
                priority: 'high'
            },
            {
                type: 'study_method',
                title: 'Study Method',
                description: this.getStudyMethodRecommendation(),
                icon: '🧠',
                priority: 'medium'
            }
        ];
    }

    getOptimalStudyTime(currentHour) {
        if (currentHour < 10) {
            return 'morning sessions (9-11 AM) work best for complex topics.';
        } else if (currentHour < 15) {
            return 'afternoon sessions (2-4 PM) are ideal for review and practice.';
        } else {
            return 'evening sessions (6-8 PM) are perfect for light review.';
        }
    }

    getBreakRecommendation(currentHour) {
        if (currentHour > 12 && currentHour < 14) {
            return 'Perfect time for a lunch break to recharge.';
        } else if (currentHour > 15 && currentHour < 17) {
            return 'Consider a 15-minute walk to boost productivity.';
        } else {
            return 'Remember to take regular breaks every 45-60 minutes.';
        }
    }

    getPriorityAssignment() {
        const pendingAssignments = AppState.assignments.filter(a => !a.completed);
        if (pendingAssignments.length > 0) {
            const highPriority = pendingAssignments.find(a => a.priority === 'high');
            if (highPriority) {
                const course = AppState.courses.find(c => c.id === highPriority.courseId);
                return `Focus on ${highPriority.title} for ${course.code} (due ${formatDate(highPriority.dueDate)})`;
            }
        }
        return 'All assignments are on track. Great job!';
    }

    getStudyMethodRecommendation() {
        const methods = [
            'Try the Pomodoro Technique: 25 minutes focused study, 5-minute break.',
            'Use active recall: Test yourself without looking at notes.',
            'Practice spaced repetition: Review material at increasing intervals.',
            'Create mind maps to visualize complex relationships.',
            'Teach the concept to someone else to solidify understanding.'
        ];
        return methods[Math.floor(Math.random() * methods.length)];
    }

    renderRecommendations() {
        const container = document.getElementById('ai-recommendations');
        if (!container) return;

        const html = this.recommendations.map(rec => `
            <div class="recommendation-card" data-priority="${rec.priority}">
                <div class="rec-icon">${rec.icon}</div>
                <div class="rec-content">
                    <h4 class="rec-title">${rec.title}</h4>
                    <p class="rec-description">${rec.description}</p>
                </div>
                <div class="rec-priority ${rec.priority}"></div>
            </div>
        `).join('');

        container.innerHTML = html;
    }
}

// Study Session Tracker
class StudySessionTracker {
    constructor() {
        this.activeSession = null;
        this.sessionHistory = [];
        this.init();
    }

    init() {
        this.renderSessionTracker();
        this.bindEvents();
    }

    renderSessionTracker() {
        const tracker = document.getElementById('study-tracker');
        if (!tracker) return;

        const html = `
            <div class="session-controls">
                <button id="start-session" class="btn btn-primary">Start Study Session</button>
                <div id="active-session" class="active-session hidden">
                    <div class="session-timer">
                        <span id="session-time">00:00:00</span>
                    </div>
                    <div class="session-controls">
                        <button id="pause-session" class="btn btn-secondary">Pause</button>
                        <button id="stop-session" class="btn btn-danger">Stop</button>
                    </div>
                </div>
            </div>
            <div class="session-stats">
                <div class="stat-item">
                    <span class="stat-value" id="today-study-time">0h 0m</span>
                    <span class="stat-label">Today</span>
                </div>
                <div class="stat-item">
                    <span class="stat-value" id="week-study-time">0h 0m</span>
                    <span class="stat-label">This Week</span>
                </div>
                <div class="stat-item">
                    <span class="stat-value" id="total-sessions">0</span>
                    <span class="stat-label">Sessions</span>
                </div>
            </div>
        `;

        tracker.innerHTML = html;
    }

    bindEvents() {
        document.addEventListener('click', (e) => {
            if (e.target.id === 'start-session') {
                this.startSession();
            } else if (e.target.id === 'pause-session') {
                this.pauseSession();
            } else if (e.target.id === 'stop-session') {
                this.stopSession();
            }
        });
    }

    startSession() {
        if (this.activeSession) return;

        this.activeSession = {
            id: generateId(),
            startTime: new Date(),
            duration: 0,
            paused: false
        };

        this.updateSessionDisplay();
        this.startTimer();
    }

    pauseSession() {
        if (!this.activeSession) return;

        this.activeSession.paused = !this.activeSession.paused;
        this.updateSessionDisplay();
    }

    stopSession() {
        if (!this.activeSession) return;

        this.activeSession.endTime = new Date();
        this.activeSession.duration = this.activeSession.endTime - this.activeSession.startTime;
        
        AppState.studySessions.push(this.activeSession);
        this.activeSession = null;
        
        this.updateStats();
        this.showNotification('Study session completed!', 'success');
    }

    startTimer() {
        const updateTimer = () => {
            if (!this.activeSession || this.activeSession.paused) return;

            const now = new Date();
            const elapsed = now - this.activeSession.startTime;
            
            const hours = Math.floor(elapsed / 3600000);
            const minutes = Math.floor((elapsed % 3600000) / 60000);
            const seconds = Math.floor((elapsed % 60000) / 1000);
            
            const timeDisplay = `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
            
            const timerElement = document.getElementById('session-time');
            if (timerElement) {
                timerElement.textContent = timeDisplay;
            }

            requestAnimationFrame(updateTimer);
        };

        updateTimer();
    }

    updateSessionDisplay() {
        const startBtn = document.getElementById('start-session');
        const activeSession = document.getElementById('active-session');

        if (this.activeSession) {
            startBtn.classList.add('hidden');
            activeSession.classList.remove('hidden');
        } else {
            startBtn.classList.remove('hidden');
            activeSession.classList.add('hidden');
        }
    }

    updateStats() {
        const today = new Date().toDateString();
        const thisWeek = this.getThisWeekSessions();
        
        const todayTime = this.calculateTotalTime(
            AppState.studySessions.filter(s => s.startTime.toDateString() === today)
        );
        const weekTime = this.calculateTotalTime(thisWeek);
        
        document.getElementById('today-study-time').textContent = this.formatDuration(todayTime);
        document.getElementById('week-study-time').textContent = this.formatDuration(weekTime);
        document.getElementById('total-sessions').textContent = AppState.studySessions.length;
    }

    getThisWeekSessions() {
        const now = new Date();
        const weekStart = new Date(now.setDate(now.getDate() - now.getDay()));
        weekStart.setHours(0, 0, 0, 0);
        
        return AppState.studySessions.filter(s => s.startTime >= weekStart);
    }

    calculateTotalTime(sessions) {
        return sessions.reduce((total, session) => total + session.duration, 0);
    }

    formatDuration(milliseconds) {
        const hours = Math.floor(milliseconds / 3600000);
        const minutes = Math.floor((milliseconds % 3600000) / 60000);
        return `${hours}h ${minutes}m`;
    }
}

// ApolloAI Notification System
function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = `
        <div class="notification-content">
            <span class="notification-message">${message}</span>
            <button class="notification-close">&times;</button>
        </div>
    `;

    document.body.appendChild(notification);

    anime({
        targets: notification,
        translateX: [300, 0],
        opacity: [0, 1],
        duration: 300,
        easing: 'easeOutCubic'
    });

    setTimeout(() => {
        anime({
            targets: notification,
            translateX: [0, 300],
            opacity: [1, 0],
            duration: 300,
            easing: 'easeInCubic',
            complete: () => notification.remove()
        });
    }, 3000);

    notification.querySelector('.notification-close').addEventListener('click', () => {
        anime({
            targets: notification,
            translateX: [0, 300],
            opacity: [1, 0],
            duration: 300,
            easing: 'easeInCubic',
            complete: () => notification.remove()
        });
    });
}

// Initialize ApolloAI Application
document.addEventListener('DOMContentLoaded', () => {
    // Initialize core components
    const calendar = new CalendarManager();
    const aiEngine = new AIRecommendationEngine();
    const studyTracker = new StudySessionTracker();

    // Global event handlers
    window.showNotification = showNotification;
    window.AppState = AppState;

    // Modal handlers
    document.addEventListener('click', (e) => {
        if (e.target.classList.contains('modal-close') || e.target.classList.contains('modal')) {
            const modal = e.target.closest('.modal');
            if (modal) {
                anime({
                    targets: modal.querySelector('.modal-content'),
                    scale: [1, 0.8],
                    opacity: [1, 0],
                    duration: 200,
                    easing: 'easeInCubic',
                    complete: () => modal.style.display = 'none'
                });
            }
        }
    });

    // Form submissions
    document.addEventListener('submit', (e) => {
        if (e.target.id === 'course-form') {
            e.preventDefault();
            handleCourseSubmission(e.target);
        }
    });

    // Navigation active state
    const currentPage = window.location.pathname.split('/').pop() || 'index.html';
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => {
        if (link.getAttribute('href') === currentPage) {
            link.classList.add('active');
        }
    });

    // Initialize animations
    anime({
        targets: '.fade-in',
        opacity: [0, 1],
        translateY: [20, 0],
        duration: 800,
        delay: anime.stagger(100),
        easing: 'easeOutCubic'
    });
    
    // Initialize ApolloAI enhanced features
    if (window.aiEngine) {
        console.log('🚀 ApolloAI Engine ready for space exploration!');
        
        // Add AI-powered quick actions
        const quickActionButtons = document.querySelectorAll('.quick-action-btn');
        quickActionButtons.forEach(btn => {
            btn.addEventListener('click', (e) => {
                const action = e.target.dataset.action;
                if (window.aiEngine && window.aiEngine.generateResponse) {
                    const response = window.aiEngine.generateResponse(action);
                    if (window.showNotification) {
                        window.showNotification(response.text, 'info');
                    }
                }
            });
        });
        
        // Add ApolloAI specific features
        initializeApolloAIFeatures();
    }
});

// ApolloAI specific initialization
function initializeApolloAIFeatures() {
    // Add space-themed animations
    createParticleEffect();
    
    // Initialize app-like interactions
    initializeAppInteractions();
    
    // Add ApolloAI branding to notifications
    enhanceNotifications();
}

function createParticleEffect() {
    // Create subtle particle effect for ApolloAI theme
    const canvas = document.createElement('canvas');
    canvas.style.position = 'fixed';
    canvas.style.top = '0';
    canvas.style.left = '0';
    canvas.style.width = '100%';
    canvas.style.height = '100%';
    canvas.style.pointerEvents = 'none';
    canvas.style.zIndex = '-1';
    canvas.style.opacity = '0.3';
    
    document.body.appendChild(canvas);
    
    // Simple particle animation
    const ctx = canvas.getContext('2d');
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
    
    const particles = [];
    for (let i = 0; i < 50; i++) {
        particles.push({
            x: Math.random() * canvas.width,
            y: Math.random() * canvas.height,
            vx: (Math.random() - 0.5) * 0.5,
            vy: (Math.random() - 0.5) * 0.5,
            size: Math.random() * 2 + 1
        });
    }
    
    function animateParticles() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        
        particles.forEach(particle => {
            particle.x += particle.vx;
            particle.y += particle.vy;
            
            if (particle.x < 0 || particle.x > canvas.width) particle.vx *= -1;
            if (particle.y < 0 || particle.y > canvas.height) particle.vy *= -1;
            
            ctx.beginPath();
            ctx.arc(particle.x, particle.y, particle.size, 0, Math.PI * 2);
            ctx.fillStyle = 'rgba(39, 174, 96, 0.3)';
            ctx.fill();
        });
        
        requestAnimationFrame(animateParticles);
    }
    
    animateParticles();
}

function initializeAppInteractions() {
    // Add app-like swipe gestures for mobile
    let touchStartX = 0;
    let touchStartY = 0;
    
    document.addEventListener('touchstart', (e) => {
        touchStartX = e.touches[0].clientX;
        touchStartY = e.touches[0].clientY;
    });
    
    document.addEventListener('touchend', (e) => {
        const touchEndX = e.changedTouches[0].clientX;
        const touchEndY = e.changedTouches[0].clientY;
        
        const deltaX = touchEndX - touchStartX;
        const deltaY = touchEndY - touchStartY;
        
        // Swipe detection for navigation
        if (Math.abs(deltaX) > Math.abs(deltaY) && Math.abs(deltaX) > 50) {
            if (deltaX > 0) {
                // Swipe right - previous page
                navigateApp('previous');
            } else {
                // Swipe left - next page
                navigateApp('next');
            }
        }
    });
}

function navigateApp(direction) {
    const pages = ['index.html', 'courses.html', 'analytics.html', 'settings.html'];
    const currentPage = window.location.pathname.split('/').pop() || 'index.html';
    const currentIndex = pages.indexOf(currentPage);
    
    let nextIndex;
    if (direction === 'next') {
        nextIndex = (currentIndex + 1) % pages.length;
    } else {
        nextIndex = (currentIndex - 1 + pages.length) % pages.length;
    }
    
    // Add transition animation
    anime({
        targets: document.body,
        opacity: [1, 0.8],
        duration: 200,
        complete: () => {
            window.location.href = pages[nextIndex];
        }
    });
}

function enhanceNotifications() {
    // Add ApolloAI branding to notifications
    const originalShowNotification = window.showNotification;
    window.showNotification = function(message, type = 'info') {
        // Add ApolloAI prefix to messages
        const brandedMessage = message.includes('ApolloAI') ? message : `ApolloAI: ${message}`;
        originalShowNotification(brandedMessage, type);
    };
}

function handleCourseSubmission(form) {
    const formData = new FormData(form);
    const courseData = {
        id: generateId(),
        name: formData.get('course-name'),
        code: formData.get('course-code'),
        time: formData.get('course-time'),
        day: formData.get('course-day'),
        color: formData.get('course-color') || '#4A9