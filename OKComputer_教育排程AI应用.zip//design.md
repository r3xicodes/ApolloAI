# Schedule AI App - Design System

## Design Philosophy

### Color Palette
- **Primary**: Soft educational blues (#4A90E2, #6BB6FF) - conveying trust and intelligence
- **Secondary**: Warm greens (#7ED321, #A8E6CF) - representing growth and learning
- **Accent**: Gentle orange (#F5A623) - for highlights and call-to-action elements
- **Neutral**: Clean grays (#F8F9FA, #6C757D) - for backgrounds and supporting text
- **Background**: Pure white (#FFFFFF) with subtle warm undertones

### Typography
- **Display Font**: "Inter" - Modern, clean sans-serif for headings and UI elements
- **Body Font**: "Source Sans Pro" - Highly readable for content and descriptions
- **Monospace**: "JetBrains Mono" - For code snippets and technical elements

### Visual Language
- **Minimalist Approach**: Clean, uncluttered interfaces that prioritize functionality
- **Soft Shadows**: Subtle depth without overwhelming the content
- **Rounded Corners**: 8px radius for cards and buttons, creating a friendly appearance
- **Generous Spacing**: Ample white space to reduce cognitive load
- **Consistent Iconography**: Simple, outlined icons that complement the clean aesthetic

## Visual Effects & Styling

### Used Libraries
- **Anime.js**: Smooth micro-interactions and element transitions
- **ECharts.js**: Data visualization for study analytics and progress tracking
- **Splide.js**: Image carousels for educational content and testimonials
- **p5.js**: Creative background effects and interactive elements
- **Matter.js**: Physics-based animations for engaging UI elements

### Animation & Effects
- **Subtle Fade-ins**: Elements appear with gentle opacity transitions
- **Hover Transformations**: Cards lift and scale slightly on interaction
- **Color Transitions**: Smooth color changes on interactive elements
- **Loading States**: Elegant skeleton screens and progress indicators
- **Micro-interactions**: Button press feedback and form validation animations

### Header & Navigation Effects
- **Sticky Navigation**: Smooth scroll-based opacity changes
- **Gradient Overlays**: Subtle gradients on hero sections
- **Parallax Elements**: Gentle background movement on scroll
- **Focus States**: Clear visual feedback for keyboard navigation

### Background Styling
- **Consistent Foundation**: Solid white background throughout all pages
- **Decorative Elements**: Subtle geometric patterns in header areas
- **Texture Overlays**: Minimal paper-like texture for educational feel
- **Section Differentiation**: Gentle background color variations for content areas

### Interactive Components
- **Calendar Interface**: Drag-and-drop with smooth animations
- **Form Elements**: Floating labels with smooth focus transitions
- **Modal Dialogs**: Backdrop blur effects with scale animations
- **Progress Indicators**: Animated progress bars and completion states
- **Notification System**: Toast messages with slide-in animations

### Responsive Design
- **Mobile-First**: Optimized for touch interactions and small screens
- **Flexible Grid**: CSS Grid and Flexbox for adaptive layouts
- **Scalable Typography**: Fluid font sizes that adjust to screen size
- **Touch-Friendly**: Minimum 44px touch targets for mobile usability